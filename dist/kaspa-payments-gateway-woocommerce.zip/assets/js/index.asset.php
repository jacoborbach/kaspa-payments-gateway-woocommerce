<?php
/**
 * Asset file for Kaspa Blocks integration
 */

return array(
    'dependencies' => array(
        'wc-blocks-registry',
        'wp-element',
        'wp-i18n',
        'wc-settings'
    ),
    'version' => '1.0.1'
);